const express = require('express');
const mongoose = require('mongoose');
const redis = require('redis');
const { json } = require('body-parser');
const authRoutes = require('./src/routes/authRoutes');
const userInfoRoutes = require('./src/routes/userInfoRoutes');
const accountLoginRoutes = require('./src/routes/accountLoginRoutes');

const app = express();
app.use(json());

// Terhubung ke MongoDB
mongoose.connect(process.env.MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true });

// Terhubung ke Redis
const redisClient = redis.createClient({
  host: process.env.REDIS_HOST,
  port: process.env.REDIS_PORT,
});

redisClient.on('connect', () => {
  console.log('Terhubung ke Redis');
});

// Routes
app.use('/auth', authRoutes);
app.use('/userinfo', userInfoRoutes);
app.use('/accountlogin', accountLoginRoutes);

// Middleware penanganan kesalahan
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).send('Ada yang rusak!');
});

// Mulai server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server berjalan di port ${PORT}`));

module.exports = app; // Untuk pengujian
