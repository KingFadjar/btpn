// accountLoginController.js

const AccountLogin = require('../models/accountLoginModel');

// Controller untuk mendapatkan informasi pengguna berdasarkan nomor akun
exports.getUserInfoByAccountNumber = async (req, res) => {
  try {
    const { accountNumber } = req.params;
    const userInfo = await UserInfo.findOne({ accountNumber });
    if (!userInfo) {
      return res.status(404).json({ message: "Informasi pengguna tidak ditemukan" });
    }
    res.status(200).json(userInfo);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Controller untuk mendapatkan informasi pengguna berdasarkan nomor registrasi
exports.getUserInfoByRegistrationNumber = async (req, res) => {
  try {
    const { registrationNumber } = req.params;
    const userInfo = await UserInfo.findOne({ registrationNumber });
    if (!userInfo) {
      return res.status(404).json({ message: "Informasi pengguna tidak ditemukan" });
    }
    res.status(200).json(userInfo);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Controller untuk mendapatkan akun login yang memiliki lastLoginDateTime lebih dari 3 hari yang lalu
exports.getAccountLoginOlderThanThreeDays = async (req, res) => {
  try {
    const threeDaysAgo = new Date();
    threeDaysAgo.setDate(threeDaysAgo.getDate() - 3);
    const accountLogins = await AccountLogin.find({ lastLoginDateTime: { $lt: threeDaysAgo } });
    res.status(200).json(accountLogins);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Controller untuk menambahkan akun login baru
exports.createAccountLogin = async (req, res) => {
  try {
    const { accountId, userName, password, userId } = req.body;
    // Validasi data yang diterima
    if (!accountId || !userName || !password || !userId) {
      return res.status(400).json({ message: "Semua kolom harus diisi" });
    }

    // Membuat akun login baru
    const newAccountLogin = await AccountLogin.create(req.body);
    res.status(201).json({ message: "Akun login berhasil dibuat", data: newAccountLogin });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Controller untuk mendapatkan semua akun login
exports.getAllAccountLogins = async (req, res) => {
  try {
    const accountLogins = await AccountLogin.find();
    res.status(200).json(accountLogins);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Controller untuk mendapatkan detail akun login berdasarkan accountId
exports.getAccountLoginById = async (req, res) => {
  try {
    const accountLogin = await AccountLogin.findById(req.params.id);
    if (!accountLogin) {
      return res.status(404).json({ message: "Akun login tidak ditemukan" });
    }
    res.status(200).json(accountLogin);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Controller untuk memperbarui informasi akun login
exports.updateAccountLogin = async (req, res) => {
  try {
    const { userName, password, lastLoginDateTime } = req.body;
    // Validasi data yang diterima
    if (!userName || !password || !lastLoginDateTime) {
      return res.status(400).json({ message: "Semua kolom harus diisi" });
    }

    const updatedAccountLogin = await AccountLogin.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );

    if (!updatedAccountLogin) {
      return res.status(404).json({ message: "Akun login tidak ditemukan" });
    }

    res.status(200).json({ message: "Informasi akun login berhasil diperbarui", data: updatedAccountLogin });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Controller untuk menghapus akun login
exports.deleteAccountLogin = async (req, res) => {
  try {
    const deletedAccountLogin = await AccountLogin.findByIdAndDelete(req.params.id);
    if (!deletedAccountLogin) {
      return res.status(404).json({ message: "Akun login tidak ditemukan" });
    }
    res.status(200).json({ message: "Akun login berhasil dihapus", data: deletedAccountLogin });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
