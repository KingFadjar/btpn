const UserInfo = require('../models/userInfoModel');

// Controller untuk membuat UserInfo baru
exports.createUserInfo = async (req, res) => {
  try {
    const { userId, fullName, accountNumber, emailAddress, registrationNumber } = req.body;
    // Validasi data yang diterima
    if (!userId || !fullName || !accountNumber || !emailAddress || !registrationNumber) {
      return res.status(400).json({ message: "Semua kolom harus diisi" });
    }

    // Membuat UserInfo baru
    const newUserInfo = await UserInfo.create(req.body);
    res.status(201).json({ message: "UserInfo berhasil dibuat", data: newUserInfo });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Controller untuk mendapatkan semua UserInfo
exports.getAllUserInfo = async (req, res) => {
  try {
    const userInfos = await UserInfo.find();
    res.status(200).json(userInfos);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Controller untuk mendapatkan detail UserInfo berdasarkan ID pengguna
exports.getUserInfoById = async (req, res) => {
  try {
    const userInfo = await UserInfo.findById(req.params.id);
    if (!userInfo) {
      return res.status(404).json({ message: "UserInfo tidak ditemukan" });
    }
    res.status(200).json(userInfo);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Controller untuk memperbarui informasi UserInfo
exports.updateUserInfo = async (req, res) => {
  try {
    const { fullName, accountNumber, emailAddress, registrationNumber } = req.body;
    // Validasi data yang diterima
    if (!fullName || !accountNumber || !emailAddress || !registrationNumber) {
      return res.status(400).json({ message: "Semua kolom harus diisi" });
    }

    const updatedUserInfo = await UserInfo.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );

    if (!updatedUserInfo) {
      return res.status(404).json({ message: "UserInfo tidak ditemukan" });
    }

    res.status(200).json({ message: "Informasi UserInfo berhasil diperbarui", data: updatedUserInfo });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Controller untuk menghapus UserInfo
exports.deleteUserInfo = async (req, res) => {
  try {
    const deletedUserInfo = await UserInfo.findByIdAndDelete(req.params.id);
    if (!deletedUserInfo) {
      return res.status(404).json({ message: "UserInfo tidak ditemukan" });
    }
    res.status(200).json({ message: "UserInfo berhasil dihapus", data: deletedUserInfo });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
