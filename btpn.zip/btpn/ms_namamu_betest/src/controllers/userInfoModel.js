const mongoose = require('mongoose');

const userInfoSchema = new mongoose.Schema({
    userId: { type: String, required: true, unique: true },
    fullName: { type: String, required: true },
    accountNumber: { type: String, required: true },
    emailAddress: { type: String, required: true },
    registrationNumber: { type: String, required: true, unique: true }
});

// Indexing keys
userInfoSchema.index({ accountNumber: 1 });
userInfoSchema.index({ emailAddress: 1 });

const UserInfo = mongoose.model('UserInfo', userInfoSchema);

module.exports = UserInfo;
