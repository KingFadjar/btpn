const UserInfo = require('../models/userInfoModel');

// Service untuk membuat informasi pengguna baru
exports.createUserInfo = async (userInfoData) => {
  try {
    const newUserInfo = await UserInfo.create(userInfoData);
    return newUserInfo;
  } catch (error) {
    throw new Error(error.message);
  }
};

// Service untuk mendapatkan semua informasi pengguna
exports.getAllUserInfo = async () => {
  try {
    const allUserInfo = await UserInfo.find();
    return allUserInfo;
  } catch (error) {
    throw new Error(error.message);
  }
};

// Service untuk mendapatkan informasi pengguna berdasarkan ID
exports.getUserInfoById = async (userId) => {
  try {
    const userInfo = await UserInfo.findById(userId);
    return userInfo;
  } catch (error) {
    throw new Error(error.message);
  }
};

// Service untuk memperbarui informasi pengguna
exports.updateUserInfo = async (userId, updatedUserInfo) => {
  try {
    const userInfo = await UserInfo.findByIdAndUpdate(userId, updatedUserInfo, { new: true });
    return userInfo;
  } catch (error) {
    throw new Error(error.message);
  }
};

// Service untuk menghapus informasi pengguna
exports.deleteUserInfo = async (userId) => {
  try {
    const deletedUserInfo = await UserInfo.findByIdAndDelete(userId);
    return deletedUserInfo;
  } catch (error) {
    throw new Error(error.message);
  }
};
