const AccountLogin = require('../models/accountLoginModel');

// Service untuk membuat akun login baru
exports.createAccountLogin = async (accountData) => {
  try {
    return await AccountLogin.create(accountData);
  } catch (error) {
    throw new Error(error.message);
  }
};

// Service untuk mendapatkan semua akun login
exports.getAllAccountLogins = async () => {
  try {
    return await AccountLogin.find();
  } catch (error) {
    throw new Error(error.message);
  }
};

// Service untuk mendapatkan detail akun login berdasarkan ID
exports.getAccountLoginById = async (accountId) => {
  try {
    return await AccountLogin.findById(accountId);
  } catch (error) {
    throw new Error(error.message);
  }
};

// Service untuk memperbarui informasi akun login
exports.updateAccountLogin = async (accountId, updateData) => {
  try {
    return await AccountLogin.findByIdAndUpdate(accountId, updateData, { new: true });
  } catch (error) {
    throw new Error(error.message);
  }
};

// Service untuk menghapus akun login
exports.deleteAccountLogin = async (accountId) => {
  try {
    return await AccountLogin.findByIdAndDelete(accountId);
  } catch (error) {
    throw new Error(error.message);
  }
};
