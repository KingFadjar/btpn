// userInfoService.test.js
const { getUserInfoById } = require('./userInfoService');
const UserInfo = require('../models/userInfoModel');

jest.mock('../models/userInfoModel', () => ({
  findById: jest.fn(),
}));

describe('getUserInfoById', () => {
  it('should return user info when valid user ID is provided', async () => {
    const mockUserInfo = { _id: '123', fullName: 'John Doe' };
    UserInfo.findById.mockResolvedValueOnce(mockUserInfo);

    const userId = '123';
    const userInfo = await getUserInfoById(userId);

    expect(userInfo).toEqual(mockUserInfo);
    expect(UserInfo.findById).toHaveBeenCalledWith(userId);
  });

  it('should throw an error when invalid user ID is provided', async () => {
    const errorMessage = 'User not found';
    UserInfo.findById.mockRejectedValueOnce(new Error(errorMessage));

    const userId = '456';
    await expect(getUserInfoById(userId)).rejects.toThrow(errorMessage);
    expect(UserInfo.findById).toHaveBeenCalledWith(userId);
  });
});
