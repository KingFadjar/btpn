const jwt = require('jsonwebtoken');

// Service untuk menghasilkan token JWT
exports.generateToken = (userId) => {
  try {
    return jwt.sign({ userId }, process.env.JWT_SECRET, { expiresIn: '1h' });
  } catch (error) {
    throw new Error(error.message);
  }
};

// Service untuk memverifikasi token JWT
exports.verifyToken = (token) => {
  try {
    return jwt.verify(token, process.env.JWT_SECRET);
  } catch (error) {
    throw new Error(error.message);
  }
};
