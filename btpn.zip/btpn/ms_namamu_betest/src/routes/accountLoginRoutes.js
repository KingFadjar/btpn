const express = require('express');
const router = express.Router();
const accountLoginController = require('../controllers/accountLoginController');

// Middleware untuk otorisasi JWT
const authMiddleware = require('../middleware/authMiddleware');

// Route untuk membuat akun login baru
router.post('/', accountLoginController.createAccountLogin);

// Route untuk mendapatkan semua akun login
router.get('/', authMiddleware, accountLoginController.getAllAccountLogins);

// Route untuk mendapatkan detail akun login berdasarkan ID
router.get('/:id', authMiddleware, accountLoginController.getAccountLoginById);

// Route untuk memperbarui informasi akun login
router.put('/:id', authMiddleware, accountLoginController.updateAccountLogin);

// Route untuk menghapus akun login
router.delete('/:id', authMiddleware, accountLoginController.deleteAccountLogin);

module.exports = router;
