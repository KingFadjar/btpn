const express = require('express');
const router = express.Router();
const userInfoController = require('../controllers/userInfoController');

// Route untuk mendapatkan semua informasi pengguna
router.get('/', userInfoController.getAllUserInfo);

// Route untuk mendapatkan informasi pengguna berdasarkan ID
router.get('/:id', userInfoController.getUserInfoById);

// Route untuk membuat informasi pengguna baru
router.post('/', userInfoController.createUserInfo);

// Route untuk memperbarui informasi pengguna berdasarkan ID
router.put('/:id', userInfoController.updateUserInfo);

// Route untuk menghapus informasi pengguna berdasarkan ID
router.delete('/:id', userInfoController.deleteUserInfo);

// Route untuk mendapatkan informasi pengguna berdasarkan nomor akun
router.get('/accountNumber/:accountNumber', userInfoController.getUserInfoByAccountNumber);

// Route untuk mendapatkan informasi pengguna berdasarkan nomor registrasi
router.get('/registrationNumber/:registrationNumber', userInfoController.getUserInfoByRegistrationNumber);

module.exports = router;
