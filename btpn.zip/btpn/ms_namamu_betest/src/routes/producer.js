const kafka = require('kafka-node');
const client = require('./kafkaConfig');

const Producer = kafka.Producer;
const producer = new Producer(client);

producer.on('ready', () => {
    console.log('Producer is ready');
});

producer.on('error', (err) => {
    console.error('Producer error:', err);
});

module.exports = producer;
