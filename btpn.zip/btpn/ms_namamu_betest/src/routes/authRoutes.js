const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');

// Route untuk login pengguna
router.post('/login', authController.login);

// Route untuk register pengguna baru
router.post('/register', authController.register);

module.exports = router;
