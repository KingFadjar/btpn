const kafka = require('kafka-node');
const client = require('./kafkaConfig');

const Consumer = kafka.Consumer;
const consumer = new Consumer(
    client,
    [
        { topic: 'my-topic' }
    ],
    {
        autoCommit: false
    }
);

consumer.on('message', (message) => {
    console.log('Received message:', message);
});

consumer.on('error', (err) => {
    console.error('Consumer error:', err);
});

module.exports = consumer;
