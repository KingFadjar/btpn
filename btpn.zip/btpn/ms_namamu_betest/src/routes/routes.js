const express = require('express');
const router = express.Router();
const User = require('./userModel');
const producer = require('./producer');

// Routes untuk akses data pengguna
router.get('/users', async (req, res) => {
    try {
        const users = await User.find();
        res.json(users);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Routes untuk mengirim pesan ke Kafka
router.get('/send-message', async (req, res) => {
    try {
        // Kirim pesan ke topik Kafka
        const payloads = [{ topic: 'my-topic', messages: 'Hello Kafka!' }];
        producer.send(payloads, (err, data) => {
            if (err) {
                console.error('Error:', err);
                res.status(500).json({ error: 'Failed to send message to Kafka' });
            } else {
                console.log('Data:', data);
                res.status(200).json({ message: 'Message sent to Kafka' });
            }
        });
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

module.exports = router;
