const mongoose = require('mongoose');

const accountLoginSchema = new mongoose.Schema({
  accountId: {
    type: String,
    required: true,
    unique: true
  },
  userName: {
    type: String,
    required: true,
    unique: true
  },
  password: {
    type: String,
    required: true
  },
  lastLoginDateTime: {
    type: Date,
    required: true,
    default: Date.now
  },
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'UserInfo',
    required: true
  }
});

const AccountLogin = mongoose.model('AccountLogin', accountLoginSchema);

module.exports = AccountLogin;
