const request = require('supertest');
const app = require('../app');
const mongoose = require('mongoose');
const UserInfo = require('../models/userInfoModel');

// Sebelum menjalankan setiap tes, bersihkan koleksi UserInfo
beforeEach(async () => {
  await UserInfo.deleteMany({});
});

// Setelah semua tes selesai, putuskan koneksi MongoDB
afterAll(async () => {
  await mongoose.disconnect();
});

describe('GET by ID /userinfo/:id', () => {
  test('It should get UserInfo by ID', async () => {
    const newUserInfo = await UserInfo.create({
      userId: '123',
      fullName: 'John Doe',
      accountNumber: '789',
      emailAddress: 'john@example.com',
      registrationNumber: '456'
    });

    const res = await request(app)
      .get(`/userinfo/${newUserInfo._id}`);
    expect(res.statusCode).toBe(200);
    expect(res.body).toHaveProperty('_id', newUserInfo._id.toString());
  });

  test('It should return 404 if UserInfo is not found', async () => {
    const res = await request(app)
      .get('/userinfo/60963bd4e06234023c330d7b'); // ID yang tidak ada
    expect(res.statusCode).toBe(404);
  });
});

describe('PUT /userinfo/:id', () => {
  test('It should update UserInfo by ID', async () => {
    const newUserInfo = await UserInfo.create({
      userId: '123',
      fullName: 'John Doe',
      accountNumber: '789',
      emailAddress: 'john@example.com',
      registrationNumber: '456'
    });

    const res = await request(app)
      .put(`/userinfo/${newUserInfo._id}`)
      .send({
        fullName: 'Updated John Doe'
      });
    expect(res.statusCode).toBe(200);
    expect(res.body).toHaveProperty('message', 'Informasi UserInfo berhasil diperbarui');
    expect(res.body.data).toHaveProperty('fullName', 'Updated John Doe');
  });

  test('It should return 404 if UserInfo is not found', async () => {
    const res = await request(app)
      .put('/userinfo/60963bd4e06234023c330d7b') // ID yang tidak ada
      .send({
        fullName: 'Updated John Doe'
      });
    expect(res.statusCode).toBe(404);
  });
});

describe('DELETE /userinfo/:id', () => {
  test('It should delete UserInfo by ID', async () => {
    const newUserInfo = await UserInfo.create({
      userId: '123',
      fullName: 'John Doe',
      accountNumber: '789',
      emailAddress: 'john@example.com',
      registrationNumber: '456'
    });

    const res = await request(app)
      .delete(`/userinfo/${newUserInfo._id}`);
    expect(res.statusCode).toBe(200);
    expect(res.body).toHaveProperty('message', 'UserInfo berhasil dihapus');
    expect(res.body.data).toHaveProperty('_id', newUserInfo._id.toString());
  });

  test('It should return 404 if UserInfo is not found', async () => {
    const res = await request(app)
      .delete('/userinfo/60963bd4e06234023c330d7b'); // ID yang tidak ada
    expect(res.statusCode).toBe(404);
  });
});
