const request = require('supertest');
const app = require('../app');
const mongoose = require('mongoose');
const AccountLogin = require('../models/accountLoginModel');

// Sebelum menjalankan setiap tes, bersihkan koleksi akun login
beforeEach(async () => {
  await AccountLogin.deleteMany({});
});

// Setelah semua tes selesai, putuskan koneksi MongoDB
afterAll(async () => {
  await mongoose.disconnect();
});

describe('GET by ID /accountlogin/:id', () => {
  test('It should get account login by ID', async () => {
    const newAccountLogin = await AccountLogin.create({
      accountId: '123',
      userName: 'user1',
      password: 'password123',
      lastLoginDateTime: new Date(),
      userId: '456'
    });

    const res = await request(app)
      .get(`/accountlogin/${newAccountLogin._id}`);
    expect(res.statusCode).toBe(200);
    expect(res.body).toHaveProperty('_id', newAccountLogin._id.toString());
  });

  test('It should return 404 if account login is not found', async () => {
    const res = await request(app)
      .get('/accountlogin/60963bd4e06234023c330d7b'); // ID yang tidak ada
    expect(res.statusCode).toBe(404);
  });
});

describe('PUT /accountlogin/:id', () => {
  test('It should update account login by ID', async () => {
    const newAccountLogin = await AccountLogin.create({
      accountId: '123',
      userName: 'user1',
      password: 'password123',
      lastLoginDateTime: new Date(),
      userId: '456'
    });

    const res = await request(app)
      .put(`/accountlogin/${newAccountLogin._id}`)
      .send({
        userName: 'updated_user'
      });
    expect(res.statusCode).toBe(200);
    expect(res.body).toHaveProperty('message', 'Informasi akun login berhasil diperbarui');
    expect(res.body.data).toHaveProperty('userName', 'updated_user');
  });

  test('It should return 404 if account login is not found', async () => {
    const res = await request(app)
      .put('/accountlogin/60963bd4e06234023c330d7b') // ID yang tidak ada
      .send({
        userName: 'updated_user'
      });
    expect(res.statusCode).toBe(404);
  });
});

describe('DELETE /accountlogin/:id', () => {
  test('It should delete account login by ID', async () => {
    const newAccountLogin = await AccountLogin.create({
      accountId: '123',
      userName: 'user1',
      password: 'password123',
      lastLoginDateTime: new Date(),
      userId: '456'
    });

    const res = await request(app)
      .delete(`/accountlogin/${newAccountLogin._id}`);
    expect(res.statusCode).toBe(200);
    expect(res.body).toHaveProperty('message', 'Akun login berhasil dihapus');
    expect(res.body.data).toHaveProperty('_id', newAccountLogin._id.toString());
  });

  test('It should return 404 if account login is not found', async () => {
    const res = await request(app)
      .delete('/accountlogin/60963bd4e06234023c330d7b'); // ID yang tidak ada
    expect(res.statusCode).toBe(404);
  });
});
